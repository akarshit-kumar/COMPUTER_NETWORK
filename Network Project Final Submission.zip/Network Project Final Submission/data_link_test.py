# import threading
# import time

# from physical_layer import PhysicalLayer
# from physical_layer import Medium
# class DataLinkLayer:
#     def __init__(self, physical_layer):
#         self.physical_layer = physical_layer  # reference to the physical layer object
#         self.next_frame_to_send = 0  # sequence number of the next frame to send
#         self.frame_expected = 0  # sequence number of the next frame expected to receive
#         self.buffer = []  # buffer for storing outgoing data packets
#         self.ack_received = True  # flag indicating whether an ACK has been received
#         self.timer = None  # timer object for retransmissions
        
#     def send(self, data):
#         # create a new data packet with the current sequence number
#         frame = {"seq": self.next_frame_to_send, "data": data}
        
#         # append the frame to the buffer
#         self.buffer.append(frame)
        
#         if self.ack_received:
#             self.start_timer()  # start the timer for the first frame
#             self.ack_received = False
            
#         # send the frame to the physical layer
#         self.physical_layer.send(frame)
        
#         # update the sequence number for the next frame
#         self.next_frame_to_send ^= 1
        
#     def receive(self):
#         # receive a frame from the physical layer
#         frame = self.physical_layer.receive()
        
#         if frame["seq"] == self.frame_expected:
#             # deliver the data to the upper layer
#             data = frame["data"]
#             self.physical_layer.deliver(data)
            
#             # update the sequence number for the next expected frame
#             self.frame_expected ^= 1
        
#         # send an ACK for the received frame
#         ack = {"seq": frame["seq"]}
#         self.physical_layer.send(ack)
        
#     def start_timer(self):
#         # start a timer for the next frame in the buffer
#         if self.buffer:
#             self.timer = threading.Timer(1.0, self.timeout)
#             self.timer.start()
        
#     def stop_timer(self):
#         # stop the timer
#         if self.timer:
#             self.timer.cancel()
#             self.timer = None
            
#     def timeout(self):
#         # retransmit the first frame in the buffer
#         frame = self.buffer[0]
#         self.physical_layer.send(frame)
        
#         # restart the timer
#         self.start_timer()
        
#     def receive_ack(self):
#         # receive an ACK from the physical layer
#         ack = self.physical_layer.receive()
        
#         if ack["seq"] == self.next_frame_to_send:
#             # the ACK is for the last frame sent, so stop the timer
#             self.stop_timer()
#             self.buffer.pop(0)  # remove the sent frame from the buffer
#             self.ack_received = True
            
#             if self.buffer:
#                 self.start_timer()  # start the timer for the next frame in the buffer

# if __name__ == "__main__":
#     medium=Medium()
#     # create a physical layer object
#     physical_layer = PhysicalLayer('00:11:22:33:44:55', medium)

#     # create a data link layer object
#     data_link_layer = DataLinkLayer(physical_layer)

#     # start the data link layer thread
#     data_link_layer_thread = threading.Thread(target=data_link_layer.receive)
#     data_link_layer_thread.start()

#     # send a message
#     message = "Hello, world!"
#     data_link_layer.send(message.encode())

#     # wait for a few seconds for the message to be sent and received
#     time.sleep(5)

#     # receive the message
#     received_message = physical_layer.get_received_data().decode()
#     print("Received message:", received_message)

#     # stop the data link layer thread
#     data_link_layer.stop()
#     data_link_layer_thread.join()