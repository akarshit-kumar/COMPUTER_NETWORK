from data_link_layer import DataLinkLayer, Hub, Medium, Test
import threading

def test_data_transfer():
    medium = Medium()
    d = Test()
    d.test()
    device1 = DataLinkLayer(medium, '00:11:22:33:44:55')
    device2 = DataLinkLayer(medium, 'aa:bb:cc:dd:ee:ff')
    medium.connect(device1.device.device_id, device1)
    medium.connect(device2.device.device_id, device2)
    message = "Hellomy"
    device1.send('aa:bb:cc:dd:ee:ff', message.encode())
    print(device2.received_data)
    string_data = ''.join([byte.decode() for byte in device2.received_data])
    print(string_data)
    sending_data = device2.received_data

    frame_list = device2.received_data
    device2.received_data = []
    print(' ')
    print(' ')
    print(' ')
    print(' ')
    print(' ')

    # Go Back N
    print("Go Back N")
    device1.send_go_back_n('aa:bb:cc:dd:ee:ff', message.encode())
    print('Finally received data')
    print(device2.received_data)
    device2.received_data = []

    # Selective Repeat
    print("Selective Repeat ARQ")
    device1.send_function('aa:bb:cc:dd:ee:ff', frame_list, 3, 0.1)

    print('Finally received data')
    print(device2.received_data)

    device1.send_csma_cd('aa:bb:cc:dd:ee:ff', message.encode())
    device2.send_csma_cd('00:11:22:33:44:55', message.encode())
    device1.receive_csma_cd()

if __name__ == "__main__":
    print('Hello')
    test_data_transfer()
