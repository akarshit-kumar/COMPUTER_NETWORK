import random
import time

def simulate_stop_and_wait(packet_list):
    """
    Simulates the Stop-and-Wait protocol for the data link layer.

    Args:
    - packet_list (list): a list of packets to send

    Returns:
    - A tuple containing the list of acknowledged packets and the number of packets transmitted.
    """
    seq_num = 0
    ack_num = 0
    acked_packets = []
    transmitted_packets = 0

    while ack_num < len(packet_list):
        # Send packet
        transmitted_packets += 1
        print("Transmitting packet", seq_num, "with sequence number", seq_num)
        # Simulate packet loss with probability of 0.2
        if random.random() < 0.2:
            print("Packet", seq_num, "with sequence number", seq_num, "lost")
        else:
            # Simulate packet corruption with probability of 0.1
            if random.random() < 0.1:
                print("Packet", seq_num, "with sequence number", seq_num, "corrupted")
            else:
                acked_packets.append(seq_num)
                ack_num += 1

        # Wait for acknowledgment
        while True:
            time.sleep(1)  # Simulate time delay
            if ack_num == len(acked_packets):
                break

        # Move to next packet
        seq_num += 1

    return acked_packets, transmitted_packets




packet_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
acked_packets, transmitted_packets = simulate_stop_and_wait(packet_list)
print("Total packets transmitted:", transmitted_packets)
print("Acknowledged packets:", acked_packets)
