import threading
import random

class DataLinkLayer:
    def __init__(self, physical_layer, window_size):
        self.physical_layer = physical_layer  # reference to the physical layer object
        self.window_size = window_size  # size of the sending window
        self.next_frame_to_send = 0  # sequence number of the next frame to send
        self.frame_expected = 0  # sequence number of the next frame expected to receive
        self.buffer = []  # buffer for storing outgoing data packets
        self.ack_received = True  # flag indicating whether an ACK has been received
        self.timer = None  # timer object for retransmissions
        
    def send(self, data):
        # create a new data packet with the current sequence number
        frame = {"seq": self.next_frame_to_send, "data": data}
        
        # append the frame to the buffer
        self.buffer.append(frame)
        
        if self.ack_received:
            self.start_timer()  # start the timer for the first frame
            self.ack_received = False
            
        # send the frames in the window to the physical layer
        self.gobackn()
        
        # update the sequence number for the next frame
        self.next_frame_to_send += len(self.buffer)
        
    def receive(self):
        # receive a frame from the physical layer
        frame = self.physical_layer.receive()
        
        if frame["seq"] == self.frame_expected:
            # deliver the data to the upper layer
            data = frame["data"]
            self.physical_layer.deliver(data)
            
            # update the sequence number for the next expected frame
            self.frame_expected += 1
        
        # send an ACK for the received frame
        ack = {"seq": frame["seq"]}
        self.physical_layer.send(ack)
        
    def start_timer(self):
        # start a timer for the next frame in the buffer
        if self.buffer:
            self.timer = threading.Timer(1.0, self.timeout)
            self.timer.start()
        
    def stop_timer(self):
        # stop the timer
        if self.timer:
            self.timer.cancel()
            self.timer = None
            
    def timeout(self):
        # retransmit the frames in the buffer
        self.next_frame_to_send -= len(self.buffer)
        self.gobackn()
        
    def receive_ack(self):
        # receive an ACK from the physical layer
        ack = self.physical_layer.receive()
        
        if ack["seq"] >= self.next_frame_to_send - len(self.buffer) and ack["seq"] < self.next_frame_to_send:
            # update the buffer with the ACKed frames
            acked_frames = ack["seq"] - (self.next_frame_to_send - len(self.buffer))
            self.buffer = self.buffer[acked_frames:]
            self.ack_received = True
            
            if self.buffer:
                self.start_timer()  # start the timer for the next frame in the buffer
        
    def gobackn(self):
        # Send frames in the window using the Go-Back-N protocol
        window_start = 0
        window_end = self.window_size - 1

        while window_start < len(self.buffer):
            # Send packets in the window
            for i in range(window_start, min(window_end + 1, len(self.buffer))):
                frame = self.buffer[i]
                print(f"Transmitting packet {i} with sequence number {frame['seq']}")

                # Simulate packet loss with probability of 0.
