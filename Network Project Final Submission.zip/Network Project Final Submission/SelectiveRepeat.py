import random
from typing import List

class selective_repeat:
    def __init__(self) -> None:
        self.frames = ["Frame 0", "Frame 1", "Frame 2", "Frame 3", "Frame 4", "Frame 5", "Frame 6"]

    def simulate_channel(self, frame):
        if random.random() < 0.2:  # simulate packet loss
            return None
        return self.receive_selective_repeat(frame)

    def send_selective_repeat(self, frames: List[str]):
        window_size = 4
        base = 0
        next_seq_num = 0
        while base < len(frames):
            # Send packets in the window
            for i in range(base, min(base + window_size, len(frames))):
                print(f"Sending frame {i}")
                self.simulate_channel(frames[i])
            
            # Wait for acknowledgements
            for i in range(base, min(base + window_size, len(frames))):
                ack = self.simulate_channel(None)
                while ack is None:
                    ack = self.simulate_channel(None)
                print(f"Receiving ack for frame {i}")
                next_seq_num = i + 1
            
            # Move window
            if next_seq_num > base:
                base = next_seq_num

    def receive_selective_repeat(self, frame):
        window_size = 4
        base = 0
        while True:
            # Wait for packets in the window
            expected_seq_num = base
            for i in range(base, base + window_size):
                if frame is None:
                    return None
                if i == expected_seq_num:
                    print(f"Receiving frame {i}")
                    expected_seq_num += 1
                    frame = self.simulate_channel(f"ACK{i}")
                else:
                    print(f"Frame {i} received out of order")
            
            # Move window
            base = expected_seq_num

            if frame == "DONE":
                break

        # Send final acknowledgements
        for i in range(base, len(self.frames)):
            ack = self.simulate_channel(None)
            while ack is None:
                ack = self.simulate_channel(None)
            print(f"Receiving ack for frame {i}")

        # Signal end of transmission
        self.simulate_channel("DONE")

if __name__ == '__main__':
    s = selective_repeat()
    frames = ["Frame 0", "Frame 1", "Frame 2", "Frame 3", "Frame 4", "Frame 5", "Frame 6"]
    s.send_selective_repeat(frames)
