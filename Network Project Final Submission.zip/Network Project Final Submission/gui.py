import tkinter as tk
import final_interface

# Create the main tkinter window
root = tk.Tk()

# Create a label and an entry field for the user to enter data
label = tk.Label(root, text="Enter data:")
label.pack()
entry = tk.Entry(root)
entry.pack()

# Define a function to send the data to the final_interface.py file
def send_info():
    data = entry.get()  # Get the user-entered data
    final_interface.process_data(data)  # Call the function in final_interface.py to process the data
    result_label.config(text=final_interface.get_result())  # Update the result label with the data returned from final_interface.py

# Create a button to send the data to final_interface.py when clicked
button = tk.Button(root, text="Send", command=send_info)
button.pack()


result_label = tk.Label(root, text="")
result_label.pack()

root.mainloop()
