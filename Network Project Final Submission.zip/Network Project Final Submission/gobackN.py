import random


def gobackn(data, window_size):
    """
    Simulates the Go-Back-N protocol for the data link layer.

    Args:
    - data (list): a list of packets to send
    - window_size (int): the size of the sending window

    Returns:
    - A tuple containing the list of acknowledged packets and the number of packets transmitted.
    """
    seq_num = 0
    ack_num = 0
    acked_packets = []
    transmitted_packets = 0
    window_start = 0
    window_end = window_size - 1

    while ack_num < len(data):
        for i in range(window_start, min(window_end + 1, len(data))):
            transmitted_packets += 1
            print(f"Transmitting packet {i} with sequence number {seq_num}")
            
            if random.random() < 0.2:
                print(f"Packet {i} with sequence number {seq_num} lost")
            else:
                if random.random() < 0.1:
                    print(f"Packet {i} with sequence number {seq_num} corrupted")
                else:
                    acked_packets.append(i)

            seq_num += 1

        while True:
            try:
                ack = acked_packets.index(ack_num)
                print(f"Received ACK for packet {ack_num}")
                acked_packets = acked_packets[ack+1:]
                ack_num += 1
                break
            except ValueError:
                # No ACK received yet
                pass

        window_start += len(acked_packets)
        window_end = window_start + window_size - 1

    return acked_packets, transmitted_packets


data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
window_size = 4

acked_packets, transmitted_packets = gobackn(data, window_size)

print("Total packets transmitted:", transmitted_packets)
print("Acknowledged packets:", acked_packets)
