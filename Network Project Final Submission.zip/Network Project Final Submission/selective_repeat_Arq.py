import random
import time

class SelectiveRepeat:
    def __init__(self, frame_list, window_size, error_probability):
        self.frame_list = frame_list
        self.window_size = window_size
        self.error_probability = error_probability
        self.next_frame_to_send = 0
        self.send_window = {}
        self.receive_window = {}
        self.timers = {}
        
    def send_selective_repeat(self):
        while self.next_frame_to_send < len(self.frame_list):
            while len(self.send_window) < self.window_size and self.next_frame_to_send < len(self.frame_list):
                frame = self.frame_list[self.next_frame_to_send]
                self.send_window[self.next_frame_to_send] = frame
                self.timers[self.next_frame_to_send] = time.time()
                self.next_frame_to_send += 1
                
            for frame_number, frame in self.send_window.items():
                if frame_number not in self.receive_window:
                    if self.error_probability == 0 or self.error_probability > 0 and self.check_error(self.error_probability):
                        print(f"Sending frame {frame_number}: {frame}")
                        self.receive_window[frame_number] = None
                
            self.check_timeouts()
            
    def receive(self):
        while True:
            frame_number = int(input("Enter received frame number (-1 to exit): "))
            if frame_number == -1:
                break
                
            if frame_number in self.receive_window:
                if self.receive_window[frame_number] is None:
                    self.receive_window[frame_number] = True
                    print(f"Received frame {frame_number} successfully!")
                    self.send_ack(frame_number)
                else:
                    print(f"Duplicate frame {frame_number} received!")
                    self.send_ack(frame_number)
            else:
                print(f"Received frame {frame_number} out of order!")
                self.send_nak(frame_number)
                
    def check_error(self, probability):
        return True if random.random() < probability else False
    
    def send_ack(self, frame_number):
        print(f"Sending ACK for frame {frame_number}")
        
    def send_nak(self, frame_number):
        print(f"Sending NAK for frame {frame_number}")
        
    def check_timeouts(self):
        for frame_number, timer in self.timers.items():
            if time.time() - timer > 5:
                print(f"Timeout occurred for frame {frame_number}")
                self.timers[frame_number] = time.time()
                self.send_window[frame_number] = self.frame_list[frame_number]
                self.receive_window.pop(frame_number)
                
def start_timer():
    return time.time()

def end_timer(start_time):
    return time.time() - start_time

def main():
    frame_list = ["Frame 0", "Frame 1", "Frame 2", "Frame 3", "Frame 4"]
    window_size = 3
    error_probability = 0.3
    
    d = SelectiveRepeat(frame_list, window_size, error_probability)
    start_time = start_timer()
    d.send_selective_repeat()
    end_time = end_timer(start_time)
    print(f"Total time taken to send frames: {end_time}")
    
    d.receive()

if __name__ == '__main__':
    main()
