import random

class TransportLayer:
    def __init__(self, router):
        self.router = router
        self.port_mappings = {}

    def register_port(self, port, process):
        self.port_mappings[port] = process

    def send(self, source_port, destination_ip, destination_port, data):
        if source_port in self.port_mappings:
            process = self.port_mappings[source_port]
            interface_name = process.interface_name 
            source_mac = self.router.interfaces[interface_name]['mac']
            source_ip = self.router.interfaces[interface_name]['ip']
            destination_mac = self.router.route_packet(source_ip, source_mac, destination_ip)

            if destination_mac:
                frame = {
                    'source_mac': source_mac,
                    'destination_mac': destination_mac,
                    'source_port': source_port,
                    'destination_port': destination_port,
                    'data': data
                }
                self.router.data_link_layer.send_packet(source_ip, source_mac, destination_ip, frame)
            else:
                print("No route found for destination IP.")
        else:
            print(f"No process registered for source port: {source_port}.")


    def receive(self, frame):
        source_port = frame['source_port']
        destination_port = frame['destination_port']
        data = frame['data']

        if destination_port in self.port_mappings:
            process = self.port_mappings[destination_port]
            process.receive(data)
        else:
            print(f"No process registered for destination port: {destination_port}.")


class Process:
    def __init__(self, transport_layer, port, interface_name):
        self.transport_layer = transport_layer
        self.port = port
        self.interface_name = interface_name  # Assign the interface name to the process
        self.transport_layer.register_port(port, self)

    def send(self, destination_ip, destination_port, data):
        self.transport_layer.send(self.port, destination_ip, destination_port, data)

    def receive(self, data):
        print(f"Data received at port {self.port}: {data}")


class Router:
    def __init__(self, data_link_layer):
        self.interfaces = {}
        self.routing_table = {}
        self.data_link_layer = data_link_layer

    def configure_interface(self, interface_name, ip_address, subnet_mask):
        self.interfaces[interface_name] = {
            'ip': ip_address,
            'subnet_mask': subnet_mask,
            'mac': self.generate_mac_address()
        }
        self.routing_table[ip_address] = {'interface': interface_name, 'distance': 0, 'next_hop': interface_name}

    def add_static_route(self, destination_network, next_hop, distance):
        self.routing_table[destination_network] = {'next_hop': next_hop, 'distance': distance}

    def generate_mac_address(self):
        # Generate a random MAC address
        mac = [random.randint(0x00, 0xff) for _ in range(6)]
        mac_address = ':'.join(['{:02x}'.format(byte) for byte in mac])
        return mac_address

    def send_arp_request(self, source_ip, destination_ip):
        # Simulate sending an ARP request
        if destination_ip in self.routing_table:
            next_hop = self.routing_table[destination_ip]['next_hop']
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"ARP Request: Who has {destination_ip}? Tell {source_ip} ({interface['mac']})")
                return destination_mac
        return None

    def receive_arp_request(self, source_ip, source_mac, destination_ip):
        # Simulate receiving an ARP request
        if destination_ip in self.interfaces:
            interface = self.interfaces[destination_ip]
            destination_mac = interface['mac']
            print(f"ARP Request: Who has {destination_ip}? Tell {source_ip} ({destination_mac})")
            self.send_arp_reply(destination_ip, source_ip, source_mac, destination_mac)

    def send_arp_reply(self, source_ip, destination_ip, source_mac, destination_mac):
        # Simulate sending an ARP reply
        print(f"ARP Reply: {source_ip} ({source_mac}) is at {destination_ip} ({destination_mac})")

    def find_best_route(self, destination_ip):
        # Find the best route for the given destination IP based on distance vector routing
        best_route = None
        best_distance = float('inf')

        for network, route in self.routing_table.items():
            if network == destination_ip and route['distance'] < best_distance:
                best_route = network
                best_distance = route['distance']

        return best_route

    def route_packet(self, source_ip, source_mac, destination_ip):
        # Route the packet to the appropriate interface based on the destination IP
        best_route = self.find_best_route(destination_ip)
        if best_route:
            next_hop = self.routing_table[best_route]['next_hop']
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"Routing packet from {source_ip} to {destination_ip} via {next_hop} ({destination_mac})")
                return destination_mac
        return None

    def update_routing_table(self):
        # Perform the distance vector routing algorithm to update the routing table
        for destination_ip in self.routing_table.keys():
            if destination_ip in self.interfaces:
                # Skip interfaces
                continue

            best_distance = float('inf')
            best_next_hop = None

            for neighbor_ip, neighbor_route in self.routing_table.items():
                if neighbor_ip == destination_ip:
                    # Skip self
                    continue

                neighbor_interface = neighbor_route['interface']
                neighbor_distance = neighbor_route['distance']

                if destination_ip in self.data_link_layer.router.interfaces[neighbor_interface]['ip']:
                    # Skip if the destination is directly connected to the neighbor
                    continue

                if neighbor_distance < best_distance:
                    best_distance = neighbor_distance + 1
                    best_next_hop = neighbor_interface

            current_route = self.routing_table[destination_ip]
            if best_next_hop and (best_distance < current_route['distance'] or current_route['distance'] == 0):
                self.routing_table[destination_ip] = {'next_hop': best_next_hop, 'distance': best_distance}

    def view_routing_table(self):
        # Print the routing table
        print("Routing Table:")
        for network, route in self.routing_table.items():
            next_hop = route['next_hop']
            distance = route['distance']
            print(f"Destination: {network}, Next Hop: {next_hop}, Distance: {distance}")

    def start(self):
        # Start the router by starting the data link layer
        self.data_link_layer.start()

    def send_packet(self, source_ip, source_mac, destination_ip, data):
        # Route the packet to the appropriate interface based on the destination IP
        best_route = self.find_best_route(destination_ip)
        if best_route:
            next_hop = self.routing_table[best_route]['next_hop']
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"Routing packet from {source_ip} to {destination_ip} via {next_hop} ({destination_mac})")

                # Send the packet using the data link layer
                frame = {'source_mac': source_mac, 'destination_mac': destination_mac, 'data': data}
                self.data_link_layer.send(destination_mac, frame)
        else:
            print(f"No route found for {destination_ip}")

    def receive_packet(self, frame):
        # Process the received packet
        source_mac = frame['source_mac']
        destination_mac = frame['destination_mac']
        data = frame['data']
        print(f"Packet received: Source MAC: {source_mac}, Destination MAC: {destination_mac}, Data: {data}")

        # Update the routing table
        self.update_routing_table()


# DataLinkLayer class
class DataLinkLayer(Router):
    def __init__(self, medium):
        self.medium = medium

    def send(self, dest_address, frame):
        # Send the frame through the medium
        self.medium.send(dest_address, frame)

    def receive(self, frame):
        super().receive_packet(frame)

    def start(self):
        pass


# Example usage
class Medium:
    def send(self, dest_address, frame):
        print(f"Sending frame to {dest_address}: {frame}")
        data_link_layer.receive(frame)


medium = Medium()

data_link_layer = DataLinkLayer(medium)

# Create a router and pass the Data Link Layer as an argument
router = Router(data_link_layer)

# Instantiate the Transport Layer
transport_layer = TransportLayer(router)

# Configure interfaces
router.configure_interface('eth0', '192.168.1.1', '255.255.255.0')
router.configure_interface('eth1', '10.0.0.1', '255.255.255.0')

# Add static routes
router.add_static_route('192.168.2.0/24', 'eth0', 1)
router.add_static_route('10.0.1.0/24', 'eth1', 1)

# Start the router (which starts the data link layer)
router.start()

# Send an ARP request
source_ip = '192.168.1.2'
destination_ip = '192.168.2.5'
destination_mac = router.send_arp_request(source_ip, destination_ip)

if destination_mac is None:
    print(f"No ARP reply received for {destination_ip}")
else:
    print(f"ARP reply received: {destination_ip} ({destination_mac})")

# Simulate receiving an ARP request
source_ip = '192.168.2.5'
source_mac = 'AA:AA:AA:AA:AA:AA'
destination_ip = '192.168.1.2'
router.receive_arp_request(source_ip, source_mac, destination_ip)

# Route a packet
source_ip = '192.168.1.1'
source_mac = 'BB:BB:BB:BB:BB:BB'
destination_ip = '10.0.1.5'
destination_mac = router.route_packet(source_ip, source_mac, destination_ip)

if destination_mac is None:
    print(f"No route found for {destination_ip}")
else:
    print(f"Packet routed from {source_ip} to {destination_ip} via {destination_mac}")

# View the routing table
router.view_routing_table()

# Start the router (which starts the data link layer)
router.start()

# Send a packet
source_ip = '192.168.1.1'
source_mac = 'BB:BB:BB:BB:BB:BB'
destination_ip = '10.0.1.5'
data = 'Hello, World!'
router.send_packet(source_ip, source_mac, destination_ip, data)

# Simulate receiving the packet at the destination
frame = {'source_mac': source_mac, 'destination_mac': destination_mac, 'data': data}
data_link_layer.receive(frame)
