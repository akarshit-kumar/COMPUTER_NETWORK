import paramiko

def run_ssh_command(host, user, pwd, cmd):
    # Create an SSH client
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect to the SSH server
        client.connect(host, username=user, password=pwd)

        # Execute the command on the remote host
        stdin, stdout, stderr = client.exec_command(cmd)

        # Read the output from the command
        output = stdout.read().decode('utf-8')

        # Print the output
        print(output)

    finally:
        # Close the SSH connection
        client.close()

# Example usage
host = 'google.com'
user = 'your-username'
pwd = 'your-password'
cmd = 'ls -l'

run_ssh_command(host, user, pwd, cmd)
