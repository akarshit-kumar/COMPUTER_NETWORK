import random
import networkx as nx
import matplotlib.pyplot as plt

class CustomTransportLayer:
    def __init__(self, router):
        self.router = router
        self.port_mappings = {}

    def register_port(self, port, process):
        self.port_mappings[port] = process

    def send(self, source_port, destination_ip, destination_port, data):
        if source_port in self.port_mappings:
            process = self.port_mappings[source_port]
            interface_name = process.interface_name
            source_mac = self.router.interfaces[interface_name]['mac']
            source_ip = self.router.interfaces[interface_name]['ip']
            destination_mac = self.router.route_packet(source_ip, source_mac, destination_ip)

            if destination_mac:
                frame = {
                    'source_mac': source_mac,
                    'destination_mac': destination_mac,
                    'source_port': source_port,
                    'destination_port': destination_port,
                    'data': data
                }
                self.router.send_packet(source_ip, source_mac, destination_ip, frame)
            else:
                print("No route found for destination IP.")
        else:
            print(f"No process registered for source port: {source_port}.")

    def receive(self, frame):
        print(frame)
        data = frame['data']
        source_port = data['source_port']
        destination_port = data['destination_port']

        if destination_port in self.port_mappings.values():
            process = next(key for key, value in self.port_mappings.items() if value == destination_port)
            process.receive(data)
        else:
            print(f"No process registered for destination port: {destination_port}.")


class CustomProcess:
    def __init__(self, transport_layer, port, interface_name):
        self.transport_layer = transport_layer
        self.port = port
        self.interface_name = interface_name
        self.transport_layer.register_port(port, self)

    def send(self, destination_ip, destination_port, data):
        self.transport_layer.send(self.port, destination_ip, destination_port, data)

    def receive(self, data):
        print(f"Data received at port {self.port}: {data}")


class CustomRouter(CustomTransportLayer):
    def __init__(self, data_link_layer):
        self.interfaces = {}
        self.routing_table = {}
        self.data_link_layer = data_link_layer

    def configure_interface(self, interface_name, ip_address, subnet_mask):
        self.interfaces[interface_name] = {
            'ip': ip_address,
            'subnet_mask': subnet_mask,
            'mac': self.generate_mac_address()
        }

    def add_static_route(self, destination_network, next_hop):
        self.routing_table[destination_network] = next_hop

    def generate_mac_address(self):
        mac = [random.randint(0x00, 0xff) for _ in range(6)]
        mac_address = ':'.join(['{:02x}'.format(byte) for byte in mac])
        return mac_address

    def send_arp_request(self, source_ip, destination_ip):
        if destination_ip in self.routing_table:
            next_hop = self.routing_table[destination_ip]
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"ARP Request: Who has {destination_ip}? Tell {source_ip} ({interface['mac']})")
                return destination_mac
        return None

    def receive_arp_request(self, source_ip, source_mac, destination_ip):
        if destination_ip in self.interfaces:
            interface = self.interfaces[destination_ip]
            destination_mac = interface['mac']
            print(f"ARP Response: {source_ip} ({source_mac}) has {destination_ip} ({destination_mac})")
            return destination_mac
        return None

    def route_packet(self, source_ip, source_mac, destination_ip):
        if destination_ip in self.routing_table:
            next_hop = self.routing_table[destination_ip]
            if next_hop in self.interfaces:
                return self.interfaces[next_hop]['mac']
            else:
                return self.send_arp_request(source_ip, destination_ip)
        else:
            print(f"No route found for destination IP: {destination_ip}.")
            return None

    def send_packet(self, source_ip, source_mac, destination_ip, frame):
        destination_mac = frame['destination_mac']
        self.data_link_layer.send_frame(source_mac, destination_mac, frame)

    def receive_packet(self, frame):
        source_mac = frame['source_mac']
        destination_mac = frame['destination_mac']
        data = frame['data']

        if destination_mac == self.interfaces[self.data_link_layer.interface_name]['mac']:
            self.receive(data)
        elif destination_mac == "ff:ff:ff:ff:ff:ff":
            self.receive_arp_request(data['source_ip'], source_mac, data['destination_ip'])
        else:
            print("Packet not destined for this router.")

    def receive(self, data):
        print(f"Data received: {data}")


class CustomDataLinkLayer:
    def __init__(self, router, interface_name):
        self.router = router
        self.interface_name = interface_name

    def send_frame(self, source_mac, destination_mac, frame):
        print(f"Frame sent: Source MAC={source_mac}, Destination MAC={destination_mac}, Data={frame}")
        self.router.receive_packet(frame)

    def receive_frame(self, frame):
        print(f"Frame received: {frame}")


if __name__ == '__main__':
    router = CustomRouter(None)
    router.configure_interface("eth0", "192.168.0.1", "255.255.255.0")
    router.configure_interface("eth1", "10.0.0.1", "255.255.255.0")
    router.add_static_route("192.168.1.0/24", "eth1")

    data_link_layer = CustomDataLinkLayer(router, "eth0")
    router.data_link_layer = data_link_layer

    process1 = CustomProcess(router, 1234, "eth0")
    process2 = CustomProcess(router, 5678, "eth1")

    process1.send("192.168.1.2", 5678, "Hello!")
    process2.send("192.168.0.1", 1234, "Hi there!")
