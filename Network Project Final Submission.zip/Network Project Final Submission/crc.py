def crc(msg, div, code='000'):
    """
    Implementation of cyclic redundancy check (CRC) using polynomial division algorithm
    """
    # Append the code to the message
    msg = msg + code
    
    # Convert message and divisor to lists for easier manipulation
    msg = list(msg)
    div = list(div)
    
    # Calculate the remainder of the division
    for i in range(len(msg) - len(code)):
        if msg[i] == '0':
            continue
        for j in range(len(div)):
            msg[i+j] = str((int(msg[i+j]) + int(div[j])) % 2)
    
    # Return the remainder as the check code
    return ''.join(msg[-len(code):])

def send(msg, div, code='000'):
    """
    Simulates sending a message with CRC code appended
    """
    check = crc(msg, div, code)
    return msg + check

def receive(msg, div, code='000'):
    """
    Simulates receiving a message and checking its CRC code
    """
    check = crc(msg, div, code)
    if check == code:
        return msg[:-len(code)]
    else:
        return None
        return None
if __name__ == '__main__':
    # Test case 1: Error-free transmission
    msg = '1101011011'
    div = '1011'
    code = '000'

    # Send message
    sent_msg = send(msg, div, code)
    print(f"Sent message (error-free): {sent_msg}")

    # Receive and check message
    received_msg = receive(sent_msg, div, code)
    print(f"Received message (error-free): {received_msg}")


    # Test case 2: Erroneous transmission
    msg = '1101011011'
    div = '1011'
    code = '000'

    # Send message
    sent_msg = send(msg, div, code)

    # Simulate transmission error by flipping one bit in the message
    error_msg = sent_msg[:5] + '0' + sent_msg[6:]
    print(f"Sent message (with error): {error_msg}")

    # Receive and check message
    received_msg = receive(error_msg, div, code)
    print(f"Received message (with error): {received_msg}")
