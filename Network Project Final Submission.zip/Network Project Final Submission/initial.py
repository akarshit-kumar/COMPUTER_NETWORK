import multiprocessing

class Device:
    def __init__(self, id):
        self.id = id
    
    def receive_data(self):
        # Implement receiving data functionality
        response = "Received data"
        print(f"Process {self.id}: {response}")

    def run(self):
        self.receive_data()

if __name__ == '__main__':
    num_devices = int(input("Enter the number of devices: "))
    processes = []
    for i in range(num_devices):
        print("Yes this is my data")
        device = Device(i)
        process = multiprocessing.Process(target=device.run)
        processes.append(process)
        process.start()

    for process in processes:
        process.join()
