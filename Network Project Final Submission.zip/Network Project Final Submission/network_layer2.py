import random

class Router:
    def __init__(self, data_link_layer):
        self.interfaces = {}
        self.routing_table = {}
        self.data_link_layer = data_link_layer

    def configure_interface(self, interface_name, ip_address, subnet_mask):
        self.interfaces[interface_name] = {
            'ip': ip_address,
            'subnet_mask': subnet_mask,
            'mac': self.generate_mac_address()
        }

    def add_static_route(self, destination_network, next_hop):
        self.routing_table[destination_network] = next_hop

    def generate_mac_address(self):
        # Generate a random MAC address
        mac = [random.randint(0x00, 0xff) for _ in range(6)]
        mac_address = ':'.join(['{:02x}'.format(byte) for byte in mac])
        return mac_address

    def send_arp_request(self, source_ip, destination_ip):
        # Simulate sending an ARP request
        if destination_ip in self.routing_table:
            next_hop = self.routing_table[destination_ip]
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"ARP Request: Who has {destination_ip}? Tell {source_ip} ({interface['mac']})")
                return destination_mac
        return None

    def receive_arp_request(self, source_ip, source_mac, destination_ip):
        # Simulate receiving an ARP request
        if destination_ip in self.interfaces:
            interface = self.interfaces[destination_ip]
            destination_mac = interface['mac']
            print(f"ARP Request: Who has {destination_ip}? Tell {source_ip} ({destination_mac})")
            self.send_arp_reply(destination_ip, source_ip, source_mac, destination_mac)

    def send_arp_reply(self, source_ip, destination_ip, source_mac, destination_mac):
        # Simulate sending an ARP reply
        print(f"ARP Reply: {source_ip} ({source_mac}) is at {destination_ip} ({destination_mac})")

    def find_best_route(self, destination_ip):
        # Find the best route for the given destination IP based on longest mask matching
        best_match = None
        for network, next_hop in self.routing_table.items():
            network_ip, subnet_mask = network.split('/')
            network_ip_parts = network_ip.split('.')
            destination_ip_parts = destination_ip.split('.')
            subnet_mask = int(subnet_mask)
            match = True
            for i in range(4):
                network_ip_part = int(network_ip_parts[i])
                destination_ip_part = int(destination_ip_parts[i])
                if (network_ip_part & (255 << (32 - subnet_mask))) != (destination_ip_part & (255 << (32 - subnet_mask))):
                    match = False
                    break
            if match and (best_match is None or int(best_match.split('/')[1]) < subnet_mask):
                best_match = network

        return best_match

    def route_packet(self, source_ip, source_mac, destination_ip):
        # Route the packet to the appropriate interface based on the destination IP
        best_route = self.find_best_route(destination_ip)
        if best_route:
            next_hop = self.routing_table[best_route]
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"Routing packet from {source_ip} to {destination_ip} via {next_hop} ({destination_mac})")
                return destination_mac
        return None

    def view_routing_table(self):
        # Print the routing table
        print("Routing Table:")
        for network, next_hop in self.routing_table.items():
            print(f"Destination: {network}, Next Hop: {next_hop}")

    def start(self):
        # Start the router by starting the data link layer
        self.data_link_layer.start()

    def send_packet(self, source_ip, source_mac, destination_ip, data):
        # Route the packet to the appropriate interface based on the destination IP
        best_route = self.find_best_route(destination_ip)
        if best_route:
            next_hop = self.routing_table[best_route]
            if next_hop in self.interfaces:
                interface = self.interfaces[next_hop]
                destination_mac = interface['mac']
                print(f"Routing packet from {source_ip} to {destination_ip} via {next_hop} ({destination_mac})")

                # Send the packet using the data link layer
                frame = {'source_mac': source_mac, 'destination_mac': destination_mac, 'data': data}
                self.data_link_layer.send(destination_mac, frame)
        else:
            print(f"No route found for {destination_ip}")

    def receive_packet(self, frame):
        # Process the received packet
        source_mac = frame['source_mac']
        destination_mac = frame['destination_mac']
        data = frame['data']
        print(f"Packet received: Source MAC: {source_mac}, Destination MAC: {destination_mac}, Data: {data}")


class DataLinkLayer:
    def __init__(self, medium):
        self.medium = medium

    def send(self, dest_address, frame):
        # Send the frame through the medium
        self.medium.send(dest_address, frame)

    def receive(self, frame):
        # Process the received frame
        self.receive_packet(frame)

    def receive_packet(self, frame):
        # Process the received packet
        router.receive_packet(frame)

    def start(self):
        pass


class Medium:
    def send(self, dest_address, frame):
        print(f"Sending frame to {dest_address}: {frame}")
        data_link_layer.receive(frame)


# Instantiate the Medium
medium = Medium()

# Instantiate the Data Link Layer
data_link_layer = DataLinkLayer(medium)

# Create a router and pass the Data Link Layer as an argument
router = Router(data_link_layer)

# Configure interfaces
router.configure_interface('eth0', '192.168.1.1', '255.255.255.0')
router.configure_interface('eth1', '10.0.0.1', '255.255.255.0')

# Add static routes
router.add_static_route('192.168.2.0/24', 'eth0')
router.add_static_route('10.0.1.0/24', 'eth1')

# Start the router (which starts the data link layer)
router.start()

# Send an ARP request
source_ip = '192.168.1.2'
destination_ip = '192.168.2.5'
destination_mac = router.send_arp_request(source_ip, destination_ip)

if destination_mac is None:
    print(f"No ARP reply received for {destination_ip}")
else:
    print(f"ARP reply received: {destination_ip} ({destination_mac})")

# Simulate receiving an ARP request
source_ip = '192.168.2.5'
source_mac = 'AA:AA:AA:AA:AA:AA'
destination_ip = '192.168.1.2'
router.receive_arp_request(source_ip, source_mac, destination_ip)

# Route a packet
source_ip = '192.168.1.1'
source_mac = 'BB:BB:BB:BB:BB:BB'
destination_ip = '10.0.1.5'
destination_mac = router.route_packet(source_ip, source_mac, destination_ip)

if destination_mac is None:
    print(f"No route found for {destination_ip}")
else:
    print(f"Packet routed from {source_ip} to {destination_ip} via {destination_mac}")

# View the routing table
router.view_routing_table()

router.start()

# Send a packet
source_ip = '192.168.1.1'
source_mac = 'BB:BB:BB:BB:BB:BB'
destination_ip = '10.0.1.5'
data = 'Hello, World!'
router.send_packet(source_ip, source_mac, destination_ip, data)

# Simulate receiving the packet at the destination
frame = {'source_mac': source_mac, 'destination_mac': router.interfaces['eth1']['mac'], 'data': data}
data_link_layer.receive(frame)
