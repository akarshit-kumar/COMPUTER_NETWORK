import random
import time
class CSMA_CD:
    def __init__(self, data, packet_size, transmission_rate):
        self.data = data
        self.packet_size = packet_size
        self.transmission_rate = transmission_rate
        self.collision = False
        
    def simulate(self):
        for i in range(len(self.data)):
            print(f"Sending packet {i}")
            
            delay = random.randint(0,1)
            time.sleep(delay)
            
            if self.is_network_busy():
                print("Network is busy, waiting...")
                self.wait_until_idle()
                
            self.transmit_packet(i)
            
            transmission_time = self.packet_size / self.transmission_rate
            time.sleep(transmission_time)
            
            if self.collision:
                print(f"Collision detected while transmitting packet {i}")
                self.collision = False
                
                self.wait_until_idle()
        
    def transmit_packet(self, packet_num):
        print(f"Transmitting packet {packet_num}")
        
    def is_network_busy(self):
        return random.random() < 0.6
    
    def wait_until_idle(self):
        while self.is_network_busy():
            time.sleep(0.1)
            
            if self.is_collision():
                self.collision = True
                break
    
    def is_collision(self):
        return random.random() < 0.5

# Test the CSMA/CD protocol
data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
packet_size = 10
transmission_rate = 1

csma_cd = CSMA_CD(data, packet_size, transmission_rate)
csma_cd.simulate()