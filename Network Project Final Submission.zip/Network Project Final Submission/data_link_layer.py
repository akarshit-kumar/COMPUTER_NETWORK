import binascii
import random
import struct
import threading
import time

# from physical_layer import PhysicalLayer
class DataLinkLayer:
    def __init__(self,medium, src_address=None, dest_address=None, device1=None, device2=None):
        self.medium=medium
        if src_address is not None:
            self.src_address=src_address
        self.next_frame_to_send = 0  
        self.frame_expected = 0  
        self.buffer = []  
        self.ack_received = True  
        self.timer = None  
        self.src_address = src_address
        self.dest_address = dest_address
        self.device=PhysicalLayer(src_address,medium)
        self.unacknowledged_frames = {}  
        self.received_data=[]
        self.window=0 
        self.window_size=0
        self.rins=0
        self.frame_list=[]
    
    def send(self,dest_address, data=None,ack=None):
        if ack is not None and ack:
            self.ack_received= True
        print(data)
        self.dest_address=dest_address
        frame_list = self.framing(data)
        print('frame list is')
        print(frame_list)
        
        
        # create a new data packet with the current sequence number
        frame = dict()
        for ele in frame_list:
            frame=self.frame_data(ele) 
            # frame["seq"] = self.next_frame_to_send
            # frame["data"] = frame
            frame = {"seq": self.next_frame_to_send, "data": frame}

            self.buffer.append(frame)
            # print(type(self.device))
            
            acknoledgement_received=self.device.send_with_ack(self.dest_address,frame)
            print('Reached here in send')
            print(frame)
            print(acknoledgement_received)
            if acknoledgement_received == 'yes received':
                print(f"Yes received {self.next_frame_to_send}")
                self.next_frame_to_send^=1
            

    def receive(self,data,ack=False):
        print('Reached here in receive')
        # receive a frame from the physical layer
        frame = data
        received_data=[]
        if frame["seq"] == self.frame_expected:
            # deliver the data to the upper layer
            data = frame["data"]
            unframed_data=self.unframe_data(data)
            self.received_data.append(unframed_data[2])
            # update the sequence number for the next expected frame
            self.frame_expected ^= 1
            ack = {"seq": frame["seq"]}
            return 'yes received'

    def send_go_back_n(self,dest_address, data=None,ack=None):
        if ack is not None and ack:
            self.ack_received= True
        print(data)
        self.received_data=[]
        self.dest_address=dest_address
        frame_list = self.framing(data)
        print('frame list is')
        print(frame_list)
        window_size=3
        seq_num = 0
        ack_num = 0
        acked_packets = []
        transmitted_packets = 0
        window_start = 0
        window_end = window_size - 1
        index=0
        self.window=0
        self.window_size=window_size
        self.received_data=[]
        timers={}
        # create a new data packet with the current sequence number
        frame = dict()
        for ele in frame_list:
            frame=self.frame_data(ele) 
            seq_num=0
            for i in range(window_start, min(window_end + 1, len(data))):
                
                # print('Element in list is')
                # print(i)
                # print(index)
                print(f"Transmitting packet {i} with sequence number {seq_num}")
                
                # if random.random() < 0.2:
                #     print(f"Packet {i} with sequence number {seq_num} lost")
                # else:
                #     if random.random() < 0.1:
                #         print(f"Packet {i} with sequence number {seq_num} corrupted")
                #     else:
                #         acked_packets.append(i)
                seq_num += 1
                
                if(index>=len(frame_list)):
                    break
                # print('Element sent')
                # print(frame_list[index])
                
                timers[i] = threading.Timer(3.0, self.gobackn_handle_timeout, args=[i, timers,index])
                timers[i].start()
                time.sleep(0.1)
                elem=self.frame_data(frame_list[index])
                frame = {"seq": i, "data": elem}
                acknoledgement_received=self.device.send_with_gobackn(self.dest_address,frame)
                timers[i].cancel()
                if(acknoledgement_received=="oep"):
                    index-=i
                    i=0
                    continue
                
                index+=1
                transmitted_packets += 1
            # append the frame to the buffer
            if(index>=len(frame_list)):
                    break
            self.buffer.append(frame)
            # print(type(self.device))
            
            # acknoledgement_received=self.device.send(self.src_address,self.dest_address,frame)
        # acknoledgement_received=self.device.send_with_gobackn(self.dest_address,frame)
        # # print('Reached here in send')
        # # print(frame)
        # # print(acknoledgement_received)
        # if acknoledgement_received == 'yes received':
        #     print(f"Yes received {self.next_frame_to_send}")
        #     self.next_frame_to_send^=1
        
    def gobackn_handle_timeout(self,i,timers,index):
        index-=i
        i=0
    def receive_go_back_n(self,data,ack=False):
        # print('Reached here in receive')
        # receive a frame from the physical layer
        # self.window+=1
        frame = data
        received_data=[]
        # if frame["seq"] == self.frame_expected:
            # deliver the data to the upper layer
        data = frame["data"]
        unframed_data=self.unframe_data(data)
        self.received_data.append(unframed_data[2])
        self.frame_expected ^= 1
        ack = {"seq": frame["seq"]}
        
        self.window+=1
        if(self.window==5) and (self.rins==0):
            self.rins+=1
            for j in range(0,frame["seq"]):
                self.received_data.pop()
            self.received_data.pop()
            return "oep"
    
        
        return frame["seq"]
            # self.device.send(dest_address,src_address,True,None)
        # # send an ACK for the received frame
        # ack = {"seq": frame["seq"]}
        # # print("Anyhting")
        # self.device2.send(ack)
        

    def start_timer(self):
        # start a timer for the next frame in the buffer
        if self.buffer:
            self.timer = threading.Timer(1.0, self.timeout)
            self.timer.start()

    def stop_timer(self):
        # stop the timer
        if self.timer:
            self.timer.cancel()
            self.timer = None

    def timeout(self):
        # retransmit the first unacknowledged frame in the dictionary
        sequence_number, frame = self.unacknowledged_frames.items()[0]
        self.device.send(self.dest_address, frame)

        # restart the timer
        self.start_timer()
        
    def receive_ack(self):
        # receive an ACK from the physical layer
        ack = self.device.receive()
        
        if ack["seq"] == self.next_frame_to_send:
            # the ACK is for the last frame sent, so stop the timer
            self.stop_timer()
            self.buffer.pop(0)  # remove the sent frame from the buffer
            self.ack_received = True
            
            if self.buffer:
                self.start_timer()

    def frame_data(self,data):
        # Define constants
        
        HEADER_LENGTH = 14
        TRAILER_LENGTH = 4
        # print("Encoded Data in frame_data function is")
        # print(data)
        # print(len(data))
        # Convert source and destination MAC addresses to binary format
        src_address = binascii.unhexlify(self.src_address.replace(":", ""))
        dest_address = binascii.unhexlify(self.dest_address.replace(":", ""))
        # print(binascii.crc32(PREAMBLE.encode()))
        # Calculate CRC value of data
    
        crc_value = binascii.crc32(data) & 0xFFFFFFFF

        # Pack header fields into binary format
        header = struct.pack("!6s6sH", dest_address, src_address, len(data))

        # Pack trailer field into binary format
        trailer = struct.pack("!L", crc_value)

        # Combine  Header, Data and Trailer
        frame = ( header + data + trailer)
        # print("Frame in the frame_datafff function is given by:")
        # print(frame)
        return frame

    def unframe_data(self,frame):
        # Define constants
        # PREAMBLE = "10101010"*7 + "10101011"
        # SFD = "10101011"
        HEADER_LENGTH = 14
        TRAILER_LENGTH = 4

        # Remove Preamble and SFD
        # frame = frame[len(PREAMBLE+SFD):]

        # Unpack header fields from binary format
        header = struct.unpack("!6s6sH", frame[:HEADER_LENGTH])
        dest_address = binascii.hexlify(header[0]).decode("utf-8").upper()
        src_address = binascii.hexlify(header[1]).decode("utf-8").upper()
        data_length = header[2]

        # Remove Header and Trailer fields
        data = frame[HEADER_LENGTH:len(frame)-TRAILER_LENGTH]

        # Calculate CRC value of data
        crc_value = binascii.crc32(data) & 0xFFFFFFFF
    
        # Unpack trailer field from binary format
        trailer = struct.unpack("!L", frame[-TRAILER_LENGTH:])[0]

        # Validate the CRC value
        if trailer != crc_value:
            raise ValueError("CRC check failed, the frame may be corrupted")

        return src_address, dest_address, data
    
    
 

    # Function to simulate sending packets over the network
    def send_function(self,dest_address,frame_list, window_size, error_probability):
        base = 0  # Base of the sending window
        next_seq_num = 0  # Next sequence number to send
        index=0
        while base < len(frame_list):
            # Send packets within the sending window
            timers = {} 
            for i in range(base, min(base + window_size, len(frame_list))):
                
                packet = {"seq_num": i, "data": frame_list[i]}
                # Simulate packet loss or corruption with error probability

                print(f"Sending packet with sequence number {i}")
                # print('Element sent')
                if(index>=len(frame_list)):
                    break
                # print(frame_list[index])
                elem=self.frame_data(frame_list[index])
                frame = {"seq": i, "data": elem}
                timers[i] = threading.Timer(3.0, self.handle_timeout, args=[i, timers])
                timers[i].start()
                time.sleep(0.1)
                ack=self.device.send_with_selective_repeat(self.dest_address,frame)
                timers[i].cancel()
                index+=1
                  # Simulate network delay
            # Wait for ACKs
            expected_ack = base
            try:
                # print('Acknowledgement')
                # print(ack)
                # Wait for ACKs with a timeout
                # ack = self.receive_function(expected_ack)
                if ack[0] == "NAK":
                    print("Received NAK, retransmitting packets")
                    next_seq_num = ack[1]
                    base=ack[1]
                    break
                elif ack[1] == expected_ack:
                    print(f"Received ACK for packet with sequence number {expected_ack}")
                    base += 1
                    expected_ack += 1
                    next_seq_num += 1
                else:
                    print(f"Discarding packet with sequence number {ack[1]}")
                if(index>=len(frame_list)):
                        break
            except TimeoutError:
                print(f"Timeout waiting for ACK for packet with sequence number {expected_ack}")
                next_seq_num = base
        


    # Function to simulate receiving packets over the network
    def receive_function(self,data):
        # Simulate network delay
        
        frame=data
        data = frame["data"]
        seq_num=frame["seq"]
        unframed_data=self.unframe_data(data)
        
        # print('Received data')
        # print(self.received_data)
        # time.sleep(8)
        # Simulate receiving a packet with error probability
        if random.random() > 0.1:
            received_packet = {"seq_num": seq_num, "data": f"data for packet {seq_num}"}
            if random.random() > 0.1:
                print(f"Received packet with sequence number {seq_num}")
                self.received_data.append(unframed_data[2])
                return "ACK",seq_num
            else:
                print(f"Packet with sequence number {seq_num} lost/corrupted")
                
                return "NAK",seq_num
        else:
            print(f"Packet with sequence number {seq_num} lost/corrupted")
            return "NAK",seq_num

    def framing(self,data):
        part_length = len(data) 
    
        # Initialize an empty list to hold the parts
        parts = []
        # print('Rangeing')
        # print(data)
        # print(part_length)
        # Split the string into ten equal parts and add each part to the list
        for i in range(part_length-1):
            start = i 
            end = start + 1 
            part = data[start:end]
            # print('Part is')
            # print(part)
            parts.append(part)
            # print(parts)
            # i+=1
        
        # Return the list of parts
        return parts
    def selective_repeat_send(self,dest_address, frame_list):
        window_size = 4
        base = 0
        next_seq_num = 0
        while base < len(frame_list):
            # Send packets in the window
            for i in range(base, min(base + window_size, len(frame_list))):
                print(f"Sending frame {i}")
                self.channel(frame_list[i])
            
            # Wait for acknowledgements
            for i in range(base, min(base + window_size, len(frame_list))):
                ack = self.channel(None)
                while ack is None:
                    ack = self.channel(None)
                print(f"Receiving ack for frame {i}")
                next_seq_num = i + 1
            
            # Move window
            if next_seq_num > base:
                base = next_seq_num
    
    def receive_selective_repeat_function(self):
        window_size = 4
        base = 0
        while True:
            # Wait for packets in the window
            expected_seq_num = base
            for i in range(base, base + window_size):
                if frame is None:
                    return None
                if i == expected_seq_num:
                    print(f"Receiving frame {i}")
                    expected_seq_num += 1
                    frame = self.channel(f"ACK{i}")
                else:
                    print(f"Frame {i} received out of order")
            
            # Move window
            base = expected_seq_num

            if frame == "DONE":
                break

        # Send final acknowledgements
        for i in range(base, len(self.frames)):
            ack = self.channel(None)
            while ack is None:
                ack = self.channel(None)
            print(f"Receiving ack for frame {i}")

        # Signal end of transmission
        self.channel("DONE")
                
    def check_error(self, probability):
        return True if random.random() < probability else False
    
    def send_ack(self, frame_number):
        print(f"Sending ACK for frame {frame_number}")
        
    def send_nak(self, frame_number):
        print(f"Sending NAK for frame {frame_number}")
        
    def check_timeouts(self):
        for frame_number, timer in self.timers.items():
            if time.time() - timer > 5:
                print(f"Timeout occurred for frame {frame_number}")
                self.timers[frame_number] = time.time()
                self.send_window[frame_number] = self.frame_list[frame_number]
                self.receive_window.pop(frame_number)
        
    def send_csma_cd(self,dest_address,data):
        self.device.send_csma()
    def receive_csma_cd(self):
        self.device.receive_csma()
    def handle_timeout(self,frame_num, timers):
        print(f"Timeout for frame {frame_num}")
        timers[frame_num].cancel()
        timers[frame_num] = threading.Timer(5.0, self.handle_timeout, args=[frame_num, timers])
        timers[frame_num].start()

class PhysicalLayer(DataLinkLayer):
    def __init__(self, device_id, medium,data_link_layer=None,window_size=1):
        if data_link_layer is not None :
            self.data_link_layer = data_link_layer
        self.device_id = device_id
        self.medium = medium
        self.data_link_layer=data_link_layer 
        self.sequence_number = 0            
        self.window_size=window_size       
        
    # reference to the data_link_layer object
    def send(self,src_id, dest_id, data, ack=False):
        print(f"{src_id} sending data to {dest_id}: {data}")
        return self.medium.send(src_id, dest_id, data,ack)
    
    def receive(self,src_id, dest_address,data,ack=False):
        print(f"{self.device_id} received data: {data}")
        return super().receive(src_id,dest_address,data,ack)
    
    # reference to the physical_layer object
    def send(self, dest_id, data):
        print(f"{self.device_id} sending data to {dest_id}: {data}")
        self.medium.send(self.device_id, dest_id, data)

    def receive(self, data):
        print(f"{self.device_id} received data: {data}")
        
    def send_with_ack(self, dest_id, data):
        print(f"{self.device_id} sending data to {dest_id}: {data}")
        return self.medium.send_with_ack(self.device_id, dest_id, data)

    def receive_with_ack(self, data):
        print(f"{self.device_id} received data: {data}")
        return super().receive(data)
    
    def send_with_gobackn(self, dest_id, data):
        print(f"{self.device_id} sending data to {dest_id}: {data}")
        return self.medium.send_with_go_back_n(self.device_id, dest_id, data)

    def receive_with_gobackn(self, data):
        print(f"{self.device_id} received data: {data}")
        return super().receive(data)
    
    def send_with_selective_repeat(self, dest_id, data):
        print(f"{self.device_id} sending data to {dest_id}: {data}")
        return self.medium.send_with_selective_repeat(self.device_id, dest_id, data)

    def receive_with_selective_repeat(self, data):
        print(f"{self.device_id} received data: {data}")
        return super().receive(data)
    def send_csma(self):
        self.medium.send_csma_cd()
    def receive_csma(self):
        self.medium.receive_csma_cd()
    def encode_data(self, data):
        # Convert the data to binary
        binary_data = ''.join(format(ord(c), '08b') for c in data)
        
        # Add start and end flags to the data
        encoded_data = '01111110' + binary_data + '01111110'
        
        return encoded_data
    
    def decode_data(self, signal):
        # Remove start and end flags from the signal
        data = signal[8:-8]
        
        # Convert the binary data to characters
        decoded_data = ''
        for i in range(0, len(data), 8):
            decoded_data += chr(int(data[i:i+8], 2))
        
        return decoded_data

                        
                        
class Hub:
    def __init__(self, hub_id, medium):
        self.hub_id = hub_id
        self.medium = medium
        self.devices = []
    
    def connect(self, device):
        self.devices.append(device)
    
    def broadcast(self, data):
        print(f"{self.hub_id} broadcasting data: {data}")
        for device in self.devices:
            device.receive(data)
        self.medium.broadcast(self.hub_id, data)
class Medium:
    def __init__(self):
        self.connections = {}
        self.busy=False
    
    def connect(self, device_id, device):
        self.connections[device_id] = device
    def send_csma_cd(self):
        if self.busy==True:
            print('Network busy')
            return
        print('Network Idle')
        self.busy=True
        
    def receive_csma_cd(self):
        self.busy=False
    # reference to data link layer object
    def send_with_ack(self, src_id, dest_id,  data,ack=None):
        # print(dest_id)
        # print(data)
        
        return self.connections[dest_id].receive(data)
    
    def send_with_go_back_n(self, src_id, dest_id,  data,ack=None):
        # print(dest_id)
        # print(data)
        
        return self.connections[dest_id].receive_go_back_n(data)
    
    def send_with_selective_repeat(self, src_id, dest_id,  data,ack=None):
        # print(dest_id)
        # print(data)
        
        return self.connections[dest_id].receive_function(data)
    # reference to physical layer object
    def send(self, src_id, dest_id, data):
        # print('resda')
        self.connections[dest_id].receive(data)
        
    # def send(self, src_id, dest_id, data):
        # self.connections[dest_id].receive(data)
    
    def broadcast(self, src_id, data):
        for device_id, device in self.connections.items():
            if device_id != src_id:
                device.receive(data)

class Switch:
    def __init__(self, switch_id, medium):
        self.switch_id = switch_id
        self.medium = medium
        self.devices = []
    
    def connect(self, device):
        self.devices.append(device)
        self.medium.connect(device.device_id, device)
    
    def send(self, src_id, dest_id, data):
        # Check if the destination device is connected to the switch
        dest_device = self.medium.connections.get(dest_id, None)
        if dest_device is not None and dest_device in self.devices:
            dest_device.receive(data)
        else:
            # If the destination device is not connected to the switch, broadcast the data
            self.broadcast(src_id, data)
    
    def broadcast(self, src_id, data):
        print(f"{self.switch_id} broadcasting data: {data}")
        for device in self.devices:
            if device.device_id != src_id:
                device.receive(data)

class Bridge:
    def __init__(self, bridge_id, medium):
        self.bridge_id = bridge_id
        self.medium = medium
        self.devices = []
    
    def connect(self, device):
        self.devices.append(device)
        self.medium.connect(device.device_id, device)
    
    def send(self, src_id, dest_id, data):
        # Check if the destination device is connected to the same side of the bridge as the source device
        src_device = self.medium.connections.get(src_id, None)
        dest_device = self.medium.connections.get(dest_id, None)
        if src_device is not None and dest_device is not None:
            src_side = self.get_device_side(src_device)
            dest_side = self.get_device_side(dest_device)
            if src_side == dest_side:
                dest_device.receive(data)
            else:
                # If the destination device is connected to the other side of the bridge, broadcast the data
                self.broadcast(src_id, data)
        else:
            # If either the source or the destination device is not connected to the bridge, broadcast the data
            self.broadcast(src_id, data)
    
    def get_device_side(self, device):
        for side, devices in self.sides.items():
            if device in devices:
                return side
    
    def broadcast(self, src_id, data):
        print(f"{self.bridge_id} broadcasting data: {data}")
        for device in self.devices:
            if device.device_id != src_id:
                device.receive(data)

class Test():
    def test(self):
        medium = Medium()
        
        # Physical Layer Test Cases:
        
        # Test case 1: Two end devices with dedicated connection
        device1 = PhysicalLayer('00:11:22:33:44:55', medium)
        device2 = PhysicalLayer('aa:bb:cc:dd:ee:ff', medium)
        medium.connect(device1.device_id, device1)
        medium.connect(device2.device_id, device2)
        device1.send(device2.device_id, 'Device1 to Device2')
        device2.send(device1.device_id,'Device2 to Device1')
        print("\n")
        
        # Test case 2: Star topology with 5 end devices connected to a hub
        hub = Hub('hub1', medium)
        medium.connect(hub.hub_id, hub)
        devices = [PhysicalLayer(f"device{i}", medium) for i in range(1, 6)]
        for device in devices:
            hub.connect(device)
            medium.connect(device.device_id, device)
        
        hub.broadcast('Hello world from hub!')
        print("\n")
        
        
        # Data Link Layer Test Cases: 
        
        # Test case 1: Two end devices connected through a switch
        print("Switch is Connected with five Devices: ")
        switch = Switch('switch1', medium)
        medium.connect(switch.switch_id, switch)
        device1 = PhysicalLayer('00:11:22:33:44:55', medium)
        device2 = PhysicalLayer('aa:bb:cc:dd:ee:ff', medium)
        devices_switch = []
        for i in range(1, 6):     # 5 devices connected with hub1
            x=f"00:11:22:33:44:{i+i}{i}"
            devices_switch.append(PhysicalLayer(x, medium)) 
            print(f"Devices[{i}]: ", x)
            
        for device in devices_switch:
            switch.connect(device)
            medium.connect(device.device_id, device)
        
        print("Sending Data from Device[1] to Device[2]: ")
        devices_switch[1].send(devices_switch[2].device_id, 'Hello world from device1 to device2 through switch!')
        print("Number of Broadcast Domain for Switch: ", 1)
        print("Number of collision Domain for Switch: ", 5)
        print("\n")
        
        
        # Test case 2: Create two star topologies with five end devices connected toa hub in each case and then connect two hubs using a switch
        hub1, hub2 = [Hub("hub{i}", medium) for i in range(1, 3)]
        devices_hub1 = [PhysicalLayer(f"00:11:22:33:44:{i}{i}", medium) for i in range(1, 6)]  # 5 devices connected with hub1
        for device in devices_hub1:
            hub1.connect(device)
            medium.connect(device.device_id, device)
            
        devices_hub2 = [PhysicalLayer(f"00:11:22:33:45:{i}{i}", medium) for i in range(6, 11)]  # 5 devices connected with hub1
        for device in devices_hub2:
            hub2.connect(device)
            medium.connect(device.device_id, device)
            
        
        switch1 = Switch('switch', medium)
        medium.connect(switch1.switch_id, switch1)
        # switch.connect(hub1)
        # switch.connect(hub2)
        
        # sending data from devices_hub1[0] to devices_hub2[9]
        print("Sending Data from device[0] at left side of hub1 to device[9] at right side of hub2")
        medium.connect(devices_hub1[0].device_id, devices_hub1[0])
        devices_hub1[0].send(devices_hub2[3].device_id, 'Hello World Message from device to hub and switch to hub and then destination device')
        # devices_hub1[0].send(devices_hub2[9].device_id, 'Hello world from device1 to device2 through switch!')
        print("\n")
        
        print("Number of Broadcast Domain for Hub[1]: ", 5)
        print("Number of collision Domain for Hub[1]: ", 5)
        print("Number of Broadcast Domain for Hub[2]: ", 5)
        print("Number of collision Domain for Hub[2]: ", 5)
        print("Number of Broadcast Domain for Switch: ", 10)
        print("Number of collision Domain for Switch: ", 10)
        
        
        
        # Test case 2: Two end devices connected through a bridge
        # bridge = Bridge('bridge1', medium)
        # medium.connect(bridge.bridge_id, bridge)
        # device3 = PhysicalLayer('11:22:33:44:55:66', medium)
        # device4 = PhysicalLayer('bb:cc:dd:ee:ff:00', medium)
        # bridge.connect(device3)
        # bridge.connect(device4)
        # device3.send(device4.device_id, 'Hello world from device3 to device4 through bridge!')
    
        