import struct
import binascii

def frame_data(data, src_address, dest_address):
    # Define constants
    PREAMBLE = "10101010"*7 + "10101011"
    SFD = "10101011"
    HEADER_LENGTH = 14
    TRAILER_LENGTH = 4
    
    # Convert source and destination MAC addresses to binary format
    src_address = binascii.unhexlify(src_address.replace(":", ""))
    dest_address = binascii.unhexlify(dest_address.replace(":", ""))

    # Calculate CRC value of data
    crc_value = binascii.crc32(data) & 0xFFFFFFFF

    # Pack header fields into binary format
    header = struct.pack("!6s6sH", dest_address, src_address, len(data))

    # Pack trailer field into binary format
    trailer = struct.pack("!L", crc_value)

    # Combine Preamble, SFD, Header, Data and Trailer
    frame = (PREAMBLE.encode() + SFD.encode() + header + data + trailer)
    return frame

def unframe_data(frame):
    # Define constants
    PREAMBLE = "10101010"*7 + "10101011"
    SFD = "10101011"
    HEADER_LENGTH = 14
    TRAILER_LENGTH = 4

    # Remove Preamble and SFD
    frame = frame[len(PREAMBLE + SFD):]

    # Unpack header fields from binary format
    header = struct.unpack("!6s6sH", frame[:HEADER_LENGTH])
    dest_address = binascii.hexlify(header[0]).decode("utf-8").upper()
    src_address = binascii.hexlify(header[1]).decode("utf-8").upper()
    data_length = header[2]

    # Remove Header and Trailer fields
    data = frame[HEADER_LENGTH:len(frame)-TRAILER_LENGTH]

    # Calculate CRC value of data
    crc_value = binascii.crc32(data) & 0xFFFFFFFF

    # Unpack trailer field from binary format
    trailer = struct.unpack("!L", frame[-TRAILER_LENGTH:])[0]

    # Validate the CRC value
    if trailer != crc_value:
        raise ValueError("CRC check failed, the frame may be corrupted")

    return src_address, dest_address, data


# Test case
def test_framing():
    # Define test data and addresses
    data = b"Hello, world!"
    src_address = "00:11:22:33:44:55"
    dest_address = "AA:BB:CC:DD:EE:FF"

    # Frame the data
    framed_data = frame_data(data, src_address, dest_address)

    # Unframe the data
    src, dest, unframed_data = unframe_data(framed_data)

    # Check if the unframed data matches the original data
    assert unframed_data == data

    # Check if the source and destination addresses are correct
    assert src == src_address.replace(":", "").upper()
    assert dest == dest_address.replace(":", "").upper()

    # Modify the data and check if the CRC check fails
    modified_data = b"Hello, universe!"
    modified_framed_data = frame_data(modified_data, src_address, dest_address)
    try:
        unframe_data(modified_framed_data)
    except ValueError:
        pass
    else:
        assert False, "CRC check failed to detect data corruption"


if __name__ == "__main__":
    test_framing()
